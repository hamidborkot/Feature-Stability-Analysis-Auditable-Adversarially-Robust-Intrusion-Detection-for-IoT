import torch, numpy as np
from randomized_smoothing import RandomizedSmoothing

class TorchXAR(torch.nn.Module):
    def __init__(self, tf_weights):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Linear(tf_weights[0].shape[0], 128),
            torch.nn.ReLU(),
            torch.nn.Linear(128,64),
            torch.nn.ReLU(),
            torch.nn.Linear(64,32),
            torch.nn.ReLU(),
            torch.nn.Linear(32,1),
            torch.nn.Sigmoid()
        )

    def forward(self, x):
        return self.net(x)

model = torch.load("models/xar_dnn_torch/xar_dnn.pt")
smoothed = RandomizedSmoothing(model, sigma=0.25)

certified = []
for x,y in test_loader:
    pred, radius = smoothed.certify(x, n0=100, n=100000, alpha=0.001)
    certified.append((pred==y) & (radius >= 0.42))

print("Certified Accuracy:", np.mean(certified))
