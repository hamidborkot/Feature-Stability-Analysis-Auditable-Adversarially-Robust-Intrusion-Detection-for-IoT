def fsa_score(clean, adv):
    return np.mean(np.abs(clean - adv))

fsa_fgsm = fsa_score(clean_feats, fgsm_feats)
fsa_sem = fsa_score(clean_feats, semantic_feats)

print("ΔFSA:", fsa_fgsm - fsa_sem)
