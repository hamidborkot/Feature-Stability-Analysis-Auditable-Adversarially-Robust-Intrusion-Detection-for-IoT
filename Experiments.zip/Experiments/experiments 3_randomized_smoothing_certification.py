def semantic_packet_drop(flow, rate=0.05):
    idx = np.random.choice(len(flow), int(rate*len(flow)), replace=False)
    return np.delete(flow, idx, axis=0)

def semantic_time_warp(flow, max_ms=200):
    return flow + np.random.uniform(-max_ms, max_ms)

# Generate 5000 semantic adversarial samples
