import tensorflow as tf, numpy as np, pandas as pd
from sklearn.metrics import accuracy_score

def fgsm(model, X, y, eps=0.1):
    x = tf.convert_to_tensor(X)
    y = tf.convert_to_tensor(y.reshape(-1,1))
    with tf.GradientTape() as t:
        t.watch(x)
        loss = tf.keras.losses.binary_crossentropy(y, model(x))
    grad = t.gradient(loss, x)
    return x + eps * tf.sign(grad)

def evaluate(model, X, y):
    return accuracy_score(y, model.predict(X) > 0.5)

model = tf.keras.models.load_model("models/xar_dnn_tf/xar_dnn.h5")
# Load test data again
# Save Clean / FGSM / PGD results to CSV
