from ina219 import INA219
ina = INA219(0.1)
energy = []

for _ in range(1000):
    ina.sleep()
    start = ina.power()
    model.predict(sample)
    end = ina.power()
    energy.append((end-start)*2.3e-3)

print("Mean energy (mJ):", np.mean(energy))
